﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
//using CefSharp.Wpf;
namespace ConsoleApplicationTest
{
    internal class PaintEventArgs
    {
        public object Graphics { get; internal set; }
    }
}